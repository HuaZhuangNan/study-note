// 闭包处理
(function(window,$){
	// 这里Dom树加载完才执行
	$(function(){
		downView(); // 下拉框
		bannerViwe(); // 轮播图
	});
	
	// 下拉框
	var downView = function() {
		$(".down").hover(function(){
			$(this).prev().css("backgroundColor","#ccc");
		},function(){
			$(this).prev().css("backgroundColor","#fff");
		})
	}
	// 轮播图
	var bannerViwe=function(){
		// 初始化
		var imgsA = $("#banner >a");
		var infoA = $("#banner .info a");
		var indexLi = $("#banner li");
		var count = imgsA.length-1;
		var prevIndex = 0;
		var nextIndex = count==1?0:1;
		var isOk = true;
		setImg(prevIndex);

		// 绑定按钮
		indexLi.click(function(){
			isOk = false;
			setImg(indexLi.index(this));
		})
		// 定时播放
		if(nextIndex>0){
			setInterval(function(){
				if(isOk)
					setImg(nextIndex);
			},2*60*60)
		}
		// 设置活动图片
		function setImg(index){
			// 更新图片
			if(prevIndex!=index)
				imgsA.eq(prevIndex).slideUp();
			imgsA.eq(index).slideDown();
			// 更新图标
			if(prevIndex!=index)
				indexLi.eq(prevIndex).removeClass("active");
			indexLi.eq(index).addClass("active");
			// 更新文字
			var img = imgsA.eq(index).find("img");
			infoA.attr("href",img.attr("src")).text(img.attr("alt"));
			// 更新
			prevIndex = index;
			nextIndex = index+1>count?0:index+1;
			isOk = true;
		}
		
	}
})(window,jQuery);
// 防止冲突
jQuery.noConflict();
jQuery=undefined;